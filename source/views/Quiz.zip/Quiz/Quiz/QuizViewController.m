//
//  QuizViewController.m
//  Quiz
//
//  Created by David Groulx on 5/13/14.
//  Copyright (c) 2014 David Groulx. All rights reserved.
//

#import "QuizViewController.h"

@interface QuizViewController () {
  // Since there is only a single view controller in this application, we can store
  // the Model part of MVC directly in the control. Here we leverage existing framework
  // classes to represent a colleciton of questions.
  NSArray *questions;
  NSDictionary *currentQuestion;
}
@end

@implementation QuizViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
    // initWithNibName:bundle: is the designated initializer that is called when the
    // we try to initialize a new view controller. Here we hard-code the question questions.
    NSDictionary *q1 = @{@"question": @"What is 5 + 2?", @"answer": @"7"};
    NSDictionary *q2 = @{@"question": @"What is the capitol of South Dakota?", @"answer": @"Pierre"};
    NSDictionary *q3 = @{@"question": @"How are you feeling today?", @"answer": @"Fine"};
    questions = @[q1, q2, q3];
  }
  return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

- (IBAction)tellMeTheAnswer:(id)sender {
  // Update the user interface based on the state of the system.
  self.answer.text = currentQuestion[@"answer"];
}

- (IBAction)nextQuestion:(id)sender {
  int currentQuestionIndex = [questions indexOfObject:currentQuestion];
  int nextQuestionIndex = -1; // start with an invalid array index
  
  // Keep guessing random numbers to lookup a new question, but make
  // sure that we don't repeat the same question.
  do {
    nextQuestionIndex = arc4random_uniform([questions count]);
  } while (nextQuestionIndex == currentQuestionIndex);
  // Update the data model
  currentQuestion = questions[nextQuestionIndex];
  
  // Update the UI to reflect the new model
  self.question.text = currentQuestion[@"question"];
  self.answer.text = @"";
}

@end
