//
//  QuizViewController.h
//  Quiz
//
//  Created by David Groulx on 5/13/14.
//  Copyright (c) 2014 David Groulx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuizViewController : UIViewController

- (IBAction)tellMeTheAnswer:(id)sender; 
- (IBAction)nextQuestion:(id)sender;

@property (weak) IBOutlet UITextField *question;
@property (weak) IBOutlet UITextField *answer;

@end
